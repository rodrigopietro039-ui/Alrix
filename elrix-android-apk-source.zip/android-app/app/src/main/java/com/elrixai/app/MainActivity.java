package com.elrixai.app;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    private static final String API_URL = "https://alrix.onrender.com/chat";
    private static final String PREFS = "elrix_preferences";
    private static final String HISTORY = "history";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private LinearLayout messagesLayout;
    private EditText input;
    private TextView modeLabel;
    private JSONArray conversation = new JSONArray();
    private String mode = "criativa";
    private boolean sending = false;

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(17, 16, 26));
        getWindow().setNavigationBarColor(Color.rgb(17, 16, 26));
        buildInterface();
        loadConversation();
    }

    private void buildInterface() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(17, 16, 26));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(20), dp(14), dp(14), dp(14));
        header.setBackgroundColor(Color.rgb(17, 16, 26));
        root.addView(header, new LinearLayout.LayoutParams(-1, dp(76)));

        TextView mark = textView("E", 23, Color.WHITE);
        mark.setGravity(Gravity.CENTER);
        mark.setTypeface(null, 1);
        mark.setBackground(round(Color.rgb(141, 92, 255), dp(15)));
        header.addView(mark, new LinearLayout.LayoutParams(dp(42), dp(42)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        titleBox.setPadding(dp(12), 0, 0, 0);
        TextView title = textView("Elrix Aí", 20, Color.WHITE);
        title.setTypeface(null, 1);
        modeLabel = textView("Criativa · sua parceira de criatividade", 12, Color.rgb(166, 161, 181));
        titleBox.addView(title);
        titleBox.addView(modeLabel);
        header.addView(titleBox, new LinearLayout.LayoutParams(0, -2, 1));

        Button clear = button("＋", Color.rgb(33, 29, 49), Color.rgb(192, 159, 255));
        clear.setTextSize(25);
        clear.setOnClickListener(v -> clearConversation());
        header.addView(clear, new LinearLayout.LayoutParams(dp(42), dp(42)));

        HorizontalScrollView modeScroll = new HorizontalScrollView(this);
        modeScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout modeBar = new LinearLayout(this);
        modeBar.setPadding(dp(14), dp(8), dp(14), dp(8));
        modeBar.setGravity(Gravity.CENTER_VERTICAL);
        String[] modes = {"criativa", "tarefas", "estudos"};
        String[] labels = {"✦ Criativa", "✓ Tarefas", "◈ Estudos"};
        for (int i = 0; i < modes.length; i++) {
            final String selectedMode = modes[i];
            Button modeButton = button(labels[i], Color.rgb(25, 23, 34), Color.rgb(170, 164, 187));
            modeButton.setTextSize(12);
            modeButton.setAllCaps(false);
            modeButton.setOnClickListener(v -> setMode(selectedMode));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(dp(112), dp(36));
            if (i > 0) params.leftMargin = dp(8);
            modeBar.addView(modeButton, params);
        }
        modeScroll.addView(modeBar);
        root.addView(modeScroll, new LinearLayout.LayoutParams(-1, dp(54)));

        ScrollView scroll = new ScrollView(this);
        messagesLayout = new LinearLayout(this);
        messagesLayout.setOrientation(LinearLayout.VERTICAL);
        messagesLayout.setPadding(dp(18), dp(16), dp(18), dp(10));
        scroll.addView(messagesLayout);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout composer = new LinearLayout(this);
        composer.setGravity(Gravity.BOTTOM);
        composer.setPadding(dp(14), dp(6), dp(14), dp(6));
        input = new EditText(this);
        input.setHint("Converse com a Elrix...");
        input.setHintTextColor(Color.rgb(140, 137, 157));
        input.setTextColor(Color.WHITE);
        input.setTextSize(16);
        input.setGravity(Gravity.TOP);
        input.setPadding(dp(12), dp(10), dp(8), dp(10));
        input.setSingleLine(false);
        input.setMaxLines(4);
        input.setBackground(round(Color.rgb(33, 29, 49), dp(20)));
        composer.addView(input, new LinearLayout.LayoutParams(0, dp(58), 1));
        Button send = button("↑", Color.rgb(141, 92, 255), Color.WHITE);
        send.setTextSize(25);
        send.setOnClickListener(v -> sendMessage());
        LinearLayout.LayoutParams sendParams = new LinearLayout.LayoutParams(dp(48), dp(48));
        sendParams.leftMargin = dp(8);
        composer.addView(send, sendParams);
        root.addView(composer, new LinearLayout.LayoutParams(-1, dp(72)));

        TextView footer = textView("IA real · conversa salva neste aparelho", 10, Color.rgb(111, 106, 125));
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, new LinearLayout.LayoutParams(-1, dp(25)));
        setContentView(root);
    }

    private TextView textView(String value, float size, int color) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setTextColor(color);
        return view;
    }

    private Button button(String value, int background, int color) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextColor(color);
        button.setGravity(Gravity.CENTER);
        button.setPadding(0, 0, 0, 0);
        button.setMinHeight(0);
        button.setMinWidth(0);
        button.setBackground(round(background, dp(14)));
        return button;
    }

    private GradientDrawable round(int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius);
        return drawable;
    }

    private void setMode(String selectedMode) {
        mode = selectedMode;
        String label = selectedMode.substring(0, 1).toUpperCase() + selectedMode.substring(1);
        modeLabel.setText(label + " · sua parceira de criatividade");
    }

    private void loadConversation() {
        try {
            String saved = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(HISTORY, "");
            if (saved.isEmpty()) {
                addMessage("assistant", "Olá!! Como vai? Para que você precisará de mim hoje?!");
            } else {
                conversation = new JSONArray(saved);
                for (int i = 0; i < conversation.length(); i++) {
                    JSONObject item = conversation.getJSONObject(i);
                    addBubble(item.getString("role"), item.getString("content"));
                }
            }
        } catch (Exception ignored) {
            addMessage("assistant", "Olá!! Como vai? Para que você precisará de mim hoje?!");
        }
    }

    private void saveConversation() {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(HISTORY, conversation.toString()).apply();
    }

    private void clearConversation() {
        conversation = new JSONArray();
        messagesLayout.removeAllViews();
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(HISTORY).apply();
        addMessage("assistant", "Olá!! Como vai? Para que você precisará de mim hoje?!");
    }

    private void addMessage(String role, String content) {
        try {
            JSONObject item = new JSONObject();
            item.put("role", role);
            item.put("content", content);
            conversation.put(item);
            saveConversation();
            addBubble(role, content);
        } catch (Exception ignored) { }
    }

    private void addBubble(String role, String content) {
        boolean user = "user".equals(role);
        TextView bubble = textView(content, 16, Color.rgb(244, 241, 250));
        bubble.setPadding(dp(15), dp(12), dp(15), dp(12));
        bubble.setGravity(Gravity.CENTER_VERTICAL);
        bubble.setBackground(round(user ? Color.rgb(117, 71, 232) : Color.rgb(33, 29, 49), dp(18)));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(user ? Gravity.RIGHT : Gravity.LEFT);
        row.setPadding(0, 0, 0, dp(14));
        row.addView(bubble, new LinearLayout.LayoutParams(dp(310), -2));
        messagesLayout.addView(row);
    }

    private void sendMessage() {
        if (sending) return;
        String value = input.getText().toString().trim();
        if (value.isEmpty()) return;
        input.setText("");
        addMessage("user", value);
        sending = true;
        new Thread(() -> {
            try {
                String reply = callBackend(mode);
                mainHandler.post(() -> {
                    addMessage("assistant", reply);
                    sending = false;
                });
            } catch (Exception error) {
                mainHandler.post(() -> {
                    addMessage("assistant", "Tive um problema de conexão agora. Tente novamente em alguns instantes.");
                    sending = false;
                });
            }
        }).start();
    }

    private String callBackend(String currentMode) throws Exception {
        HttpURLConnection connection = (HttpURLConnection) new URL(API_URL).openConnection();
        connection.setRequestMethod("POST");
        connection.setConnectTimeout(20000);
        connection.setReadTimeout(90000);
        connection.setDoOutput(true);
        connection.setRequestProperty("Content-Type", "application/json; charset=utf-8");
        JSONObject payload = new JSONObject();
        payload.put("mode", currentMode);
        JSONArray recent = new JSONArray();
        int start = Math.max(0, conversation.length() - 20);
        for (int i = start; i < conversation.length(); i++) recent.put(conversation.get(i));
        payload.put("messages", recent);
        try (OutputStream output = connection.getOutputStream()) {
            output.write(payload.toString().getBytes("UTF-8"));
        }
        InputStream stream = connection.getResponseCode() >= 400 ? connection.getErrorStream() : connection.getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
        StringBuilder result = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) result.append(line);
        JSONObject response = new JSONObject(result.toString());
        if (connection.getResponseCode() >= 400) throw new Exception(response.optString("error"));
        return response.optString("reply", "Fiquei sem palavras por um instante. Pode tentar de novo?");
    }
}
